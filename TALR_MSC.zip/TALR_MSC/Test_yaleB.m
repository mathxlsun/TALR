
%% For convinience, we assume the order of the tensor is always 3;
clear;clc;
addpath('tSVD','proxFunctions','solvers','twist');
addpath('ClusteringMeasure', 'LRR', 'Nuclear_norm_l21_Algorithm', 'unlocbox');

load('yaleB.mat'); 
cls_num = length(unique(gt));
%% Note: each column is an sample (same as in LRR)
%%
%data preparation...
X{1} = X3; X{2} = X2; X{3} = X1;
for v=1:3
    [X{v}]=NormalizeData(X{v});
end
% Initialize...

K = length(X); N = size(X{1},2); %sample number

lambda = 0.0024;
beta =0.08;
num = 1;
acc_mean=zeros(1,num);
nmi_mean=zeros(1,num);
ar_mean=zeros(1,num);
f_mean=zeros(1,num);
p_mean=zeros(1,num);
r_mean=zeros(1,num);

for nn = 1:num
    for ii = 1:length(lambda)
        for jj = 1:length(beta)
            
            for k=1:K
                Z{k} = zeros(N,N); 
                W{k} = zeros(N,N);
                G{k} = zeros(N,N);
                E{k} = zeros(size(X{k},1),N); 
                Y{k} = zeros(size(X{k},1),N); 
                D{k} = zeros(N,N); 
            end
            
            w = zeros(N*N*K,1);
            g = zeros(N*N*K,1);
            dim1 = N;dim2 = N;dim3 = K;
            myNorm = 'tSVD_1';
            sX = [N, N, K];
            %set Default
            parOP         =    false;
            ABSTOL        =    1e-6;
            RELTOL        =    1e-4;
            
            Isconverg = 0;epson = 1e-5;
            iter = 1;
            mu = 10e-5;
            max_mu = 1e12; pho_mu = 2;
            rho = 0.0001; max_rho = 1e12; pho_rho = 2;
            tic;
            
            while(Isconverg == 0)
                    fprintf('----processing iter %d--------\n', iter);
                for k=1:K
                    %1 update Z^k                  
                    tmp = (X{k}'*Y{k} + mu*X{k}'*X{k} - mu*X{k}'*X{k}*D{k} - mu*X{k}'*E{k} - W{k})./rho +  G{k};
                    Z{k}=inv(eye(N,N)+ (mu/rho)*X{k}'*X{k})*tmp;
                    
                    %2 update E^k
                    F = [X{1}-X{1}*Z{1}-X{1}*D{1}+Y{1}/mu;X{2}-X{2}*Z{2}-X{2}*D{2}+Y{2}/mu;X{3}-X{3}*Z{3}-X{3}*D{3}+Y{3}/mu];
                    [Econcat] = solve_l1l2(F,lambda(ii)/mu);

                    E{1} = Econcat(1:size(X{1},1),:);
                    E{2} = Econcat(size(X{1},1)+1:size(X{1},1)+size(X{2},1),:);
                    E{3} = Econcat(size(X{1},1)+size(X{2},1)+1:end,:);
                    
                    % update Dk
                    tmp = X{k}'*Y{k} + mu*X{k}'*X{k} - mu* X{k}'*X{k}*Z{k} -mu* X{k}'*E{k};
                    D{k}=inv(2*beta(jj)*eye(N,N)+ mu*X{k}'*X{k})*tmp;                  
                    
                    %3 update Yk
                    Y{k} = Y{k} + mu*(X{k}-X{k}*(Z{k}+D{k})-E{k}); 
                 end
                
                %4 update G
                Z_tensor = cat(3, Z{:,:});
                W_tensor = cat(3, W{:,:});
                z = Z_tensor(:);
                w = W_tensor(:);
                
                %twist-version
                [g, objV] = logwshrinkObj(z + 1/rho*w,1/rho,sX,3);  
                G_tensor = reshape(g, sX);
                
                %5 update W
                w = w + rho*(z - g);
                
                %record the iteration information
                history.objval(iter+1)   =  objV;
                
                %% coverge condition
                Isconverg = 1;
                error1=0;
                error2=0;
                for k=1:K
                    norm_Z{k} = norm(X{k}-X{k}*(Z{k}+D{k})-E{k},inf);
                    error1=error1+norm_Z{k};
                    if (norm_Z{k}>epson)
                        fprintf('    norm_Z %7.10f    ', norm_Z{k});
                        Isconverg = 0;
                    end
                    G{k} = G_tensor(:,:,k);
                    W_tensor = reshape(w, sX);
                    W{k} = W_tensor(:,:,k);
                    norm_Z_G{k} = norm(Z{k}-G{k},inf);
                    error2=error2+norm_Z_G{k};
                    if (norm_Z_G{k}>epson)
                        fprintf('    norm_Z_G %7.10f    ', norm_Z_G{k});
                        Isconverg = 0;
                    end
                end
                Reconstruction(iter+1)=(error1)/K;
                Match(iter+1)=(error2)/K;
                
                if (iter>200)
                    Isconverg  = 1;
                end
             
                iter = iter + 1;
                mu = min(mu*pho_mu, max_mu);
                rho = min(rho*pho_rho, max_rho);
            end
            S = 0;
            for k=1:K
                S = S + ( abs(Z{k})+abs(Z{k}') + abs(D{k}) + abs(D{k}') )/2; 
            end
            C = SpectralClustering(S,cls_num);
            [A nmi avgent] = compute_nmi(gt,C);
            ACC = Accuracy(C,double(gt));
            [f,p,r] = compute_f(gt,C);
            [AR,RI,MI,HI]=RandIndex(gt,C);
            acc_mean(nn)=ACC;
            nmi_mean(nn)=nmi;
            ar_mean(nn)=AR;
            f_mean(nn)=f;
            p_mean(nn)=p;
            r_mean(nn)=r;
            fprintf('NMI: %.4f; ACC: %.4f; AR: %.4f; f: %.4f; p: %.4f; r: %.4f; lambda=%.4f; beta=%.4f \n', nmi, ACC, AR, f, p, r, lambda(ii), beta(jj));
                    toc;
        end
    end
end





